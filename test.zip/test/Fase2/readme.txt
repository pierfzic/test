La classe richiesta è nel file Student.java
e il file  Stud contiene il main con qualche prova.
