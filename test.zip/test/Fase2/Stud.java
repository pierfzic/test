package stud;

/**
 *
 * @author Pierfrancesco
 */
public class Stud {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student s=new Student();
        s.setBirthDate("06/09/2000");
        System.out.println("Et�: "+s.age());
        s.addGrade("10");
        s.addGrade("20");
        s.addGrade("30");
        System.out.println(s.getGrades().toString());
        System.out.println("Media voti: "+s.avg_grades());
    }
    
}
