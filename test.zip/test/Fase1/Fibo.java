/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fibo;

/**
 *
 * @author Pierfrancesco
 */
import java.math.BigInteger;

/**
 *
 * @author Pierfrancesco
 */
public class Fibo {

    public static void main(String[] args) {
        
        long idx=calcola();
        
    }
    
    
    public static long calcola() {
        
        long index=2;
        BigInteger n1, n2, somma;
        somma=new BigInteger("0");
        n1=new BigInteger("1");
        n2=new BigInteger("1");
        
        while (nCifre(somma)<1000) {
        somma = n1.add(n2);
        n1=n2;
        n2=somma;
        
        index++;
        }
        
        System.out.println("F"+index+": "+somma.toString());
        return index;
        
    }
    
    
    public static int nCifre(BigInteger x) {
        String numero=x.toString();
        return numero.length();
    }
}
