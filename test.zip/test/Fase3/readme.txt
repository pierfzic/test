Il servizio è in ascolto 

- per le chiamate GET all'indirizzo http://localhost:8080/serviziorest/resources/student/getall
e risponde con un laconico elenco degli studenti gia' inseriti

- per le chiamate POST all'indirizzo  http://localhost:8080/serviziorest/resources/student/insert
e risponde con il messaggio "Ho inserito lo studente ...."

Compilato con NetBeans 15, JDK 18, e Payara Server 5.2022.3

Esempio di utilizzo:
curl -X POST -d "first=Luigi&last=Marcone&birth=01/04/2000&grade=30" http://localhost:8080/serviziorest/resources/student/insert
Ho inserito lo studente Luigi Marcone<br>

curl -X POST -d "first=Maria&last=Merlin&birth=25/02/1957&grade=25" http://localhost:8080/serviziorest/resources/student/insert
Ho inserito lo studente Maria Merlin<br>

curl -X POST -d "first=Aldo&last=Colizzi&birth=13/03/1961&grade=25" http://localhost:8080/serviziorest/resources/student/insert
Ho inserito lo studente Aldo Colizzi<br>

curl -X GET   http://localhost:8080/serviziorest/resources/student/getall
Luigi Marcone 01/04/2000<br>
Maria Merlin 25/02/1957<br>
Aldo Colizzi 13/03/1961<br>
<br>




